sap.ui.controller("VILORE_FOODS.view.LineItem", {

	handleNavBack : function (evt) { 
		this.nav.back("Detail");
	}
});